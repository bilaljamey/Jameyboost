export default function Home() {
  return (
    <div>
      <h1>Welcome to JameyBoost!</h1>
      <p>This site gives you real-time hashtags, trends, and more!</p>
    </div>
  );
}